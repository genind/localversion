<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<?$APPLICATION->ShowHead();?>
<title><?$APPLICATION->ShowTitle();?></title>
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
<link rel="stylesheet" href="/css/style.css" type="text/css" media="screen, projection" />
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/js/cufon.js"></script>
<script type="text/javascript" src="/js/font.js"></script>
<script type="text/javascript" src="/js/scr.js"></script>
<script type="text/javascript" src="/js/jquery.ba-hashchange.min.js"></script>
<script type="text/javascript" src="/js/ajax_load.js"></script>
<script type="text/javascript">

$(function(){
		AjaxContent.init({containerDiv:"#teachers",contentDiv:"#teachers"}).ajaxify_links(".filter ul li a");

	});
$(document).ajaxSuccess(function() {
	Cufon.refresh('.filter ul li a');
 
});

</script>
<script type="text/javascript">
	var _gaq = _gaq || [];
	_gaq.push(['_setAccount','UA-34618738-1']);
	_gaq.push(['_addOrganic','images.yandex.ru','text',true]);
	_gaq.push(['_addOrganic','blogsearch.google.ru','q',true]);
	_gaq.push(['_addOrganic','blogs.yandex.ru','text',true]);
	_gaq.push(['_addOrganic','go.mail.ru','q']);
	_gaq.push(['_addOrganic','nova.rambler.ru','query']);
	_gaq.push(['_addOrganic','nigma.ru','s']);
	_gaq.push(['_addOrganic','webalta.ru','q']);
	_gaq.push(['_addOrganic','aport.ru','r']);
	_gaq.push(['_addOrganic','poisk.ru','text']);
	_gaq.push(['_addOrganic','liveinternet.ru','q']);
	_gaq.push(['_addOrganic','quintura.ru','request']);
	_gaq.push(['_addOrganic','search.qip.ru','query']);
	_gaq.push(['_addOrganic','gogo.ru','q']);
	_gaq.push(['_addOrganic','ru.yahoo.com','p']);
	_gaq.push(['_addOrganic','market.yandex.ru','text']);
	_gaq.push(['_addOrganic','price.ru','query']);
	_gaq.push(['_addOrganic','tyndex.ru','query']);
	_gaq.push(['_addOrganic','torg.mail.ru','q']);
	_gaq.push(['_addOrganic','tiu.ru','query']);
	_gaq.push(['_addOrganic','tech2u.ru','text']);
	_gaq.push(['_addOrganic','goods.marketgid.com','query']);
	_gaq.push(['_addOrganic','poisk.ngs.ru','q']);
	_gaq.push(['_addOrganic','akavita.by','z']);
	_gaq.push(['_addOrganic','tut.by','query']);
	_gaq.push(['_addOrganic','all.by','query']);
	_gaq.push(['_addOrganic','meta.ua','q']);
	_gaq.push(['_addOrganic','bigmir.net','q']);
	_gaq.push(['_addOrganic','i.ua','q']);
	_gaq.push(['_addOrganic','online.ua','q']);
	_gaq.push(['_addOrganic','a.ua','query']);
	_gaq.push(['_addOrganic','ukr.net','q']);
	_gaq.push(['_addOrganic','search.com.ua','q']);
	_gaq.push(['_addOrganic','search.ua','area']);
	_gaq.push(['_addOrganic','search.ukr.net','q']);
	_gaq.push(['_addOrganic','sm.aport.ru','key']);
	_gaq.push(['_trackPageview']);

	(function() {
	var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	})();
</script>

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter16198597 = new Ya.Metrika({id:16198597, enableAll: true, webvisor:true});
        } catch(e) {}
    });
    
    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/16198597" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</head>

<body>
<div id="panel">
<?$APPLICATION->ShowPanel();?>
</div>
<div id="wr1">
<div id="wrapper">
	<div id="header">
		<div id="logo">
        	<a href="/"><img src="/images/new-logo.png" alt="logo" /></a>
			<a href="/"><img src="/images/logo-name.png" alt="title" style="float:left; margin-left:15px; display:block;" /></a>
        </div>
        <div id="search">
       	  <span><img src="/images/course_zap.png" alt="������ �� �����" /></span>

          <span id="phone">+7 (499) 936 85 94</span>
          <br/>
<a href="/onlinerequest/" id="subscribetop" style="margin-top: -20px;"></a>  
        </div>
<div id="main_divider"><img src="/images/main-divider.png" alt="main divider" /></div>
        <div id="cabinet">
<div style="margin:5px 0 0 70px;">
<a href="#" data-reveal-id="feedback-form" id="feedback"  style="margin:5px 0 0 -58px;"></a>
</div>
<form id="searchform" action="/search/" method="get">
			 <input type="text" name="q" value="����� �� �����"  onfocus="if (this.value == '����� �� �����') {this.value = '';}" onblur="if (this.value==''){this.value='����� �� �����';}" />
			<input type="image" src="/images/search-new.png" name="btn" class="sbtn" alt="search" />
        </form>
        </div>
  </div><!-- #header-->
	<div id="menu">
	<?$APPLICATION->IncludeComponent("bitrix:menu", "menu", array(
	"ROOT_MENU_TYPE" => "top",
	"MENU_CACHE_TYPE" => "N",
	"MENU_CACHE_TIME" => "3600",
	"MENU_CACHE_USE_GROUPS" => "Y",
	"MENU_CACHE_GET_VARS" => array(
	),
	"MAX_LEVEL" => "1",
	"CHILD_MENU_TYPE" => "left",
	"USE_EXT" => "N",
	"DELAY" => "N",
	"ALLOW_MULTI_SELECT" => "N"
	),
	false
);?>
	<div class="shadow1"></div>
	</div>
	<div id="content">

        <div id="centr">
<div class="left">
<?$APPLICATION->IncludeComponent("bitrix:menu", "about", array(
	"ROOT_MENU_TYPE" => "left",
	"MENU_CACHE_TYPE" => "N",
	"MENU_CACHE_TIME" => "3600",
	"MENU_CACHE_USE_GROUPS" => "Y",
	"MENU_CACHE_GET_VARS" => array(
	),
	"MAX_LEVEL" => "1",
	"CHILD_MENU_TYPE" => "left",
	"USE_EXT" => "N",
	"DELAY" => "N",
	"ALLOW_MULTI_SELECT" => "N"
	),
	false
);?>
<div class="inner-shadow">&nbsp;</div>

<?$APPLICATION->IncludeComponent("bitrix:news.list", "courses", array(
	"IBLOCK_TYPE" => "content",
	"IBLOCK_ID" => "4",
	"NEWS_COUNT" => "50",
	"SORT_BY1" => "SORT",
	"SORT_ORDER1" => "ASC",
	"SORT_BY2" => "ID",
	"SORT_ORDER2" => "DESC",
	"FILTER_NAME" => "",
	"FIELD_CODE" => array(
		0 => "",
		1 => "",
	),
	"PROPERTY_CODE" => array(
		0 => "",
		1 => "",
	),
	"CHECK_DATES" => "Y",
	"DETAIL_URL" => "",
	"AJAX_MODE" => "N",
	"AJAX_OPTION_JUMP" => "N",
	"AJAX_OPTION_STYLE" => "Y",
	"AJAX_OPTION_HISTORY" => "N",
	"CACHE_TYPE" => "N",
	"CACHE_TIME" => "3600",
	"CACHE_FILTER" => "N",
	"CACHE_GROUPS" => "Y",
	"PREVIEW_TRUNCATE_LEN" => "",
	"ACTIVE_DATE_FORMAT" => "d.m.Y",
	"SET_TITLE" => "Y",
	"SET_STATUS_404" => "N",
	"INCLUDE_IBLOCK_INTO_CHAIN" => "Y",
	"ADD_SECTIONS_CHAIN" => "Y",
	"HIDE_LINK_WHEN_NO_DETAIL" => "N",
	"PARENT_SECTION" => "",
	"PARENT_SECTION_CODE" => "",
	"DISPLAY_TOP_PAGER" => "N",
	"DISPLAY_BOTTOM_PAGER" => "N",
	"PAGER_TITLE" => "�������",
	"PAGER_SHOW_ALWAYS" => "Y",
	"PAGER_TEMPLATE" => "newsnav",
	"PAGER_DESC_NUMBERING" => "N",
	"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
	"PAGER_SHOW_ALL" => "Y",
	"AJAX_OPTION_ADDITIONAL" => ""
	),
	false
);?>

</div>

<div class="right">
<h1><?$APPLICATION->ShowTitle();?></h1>
        