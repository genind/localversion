<?
if(defined("B_PROLOG_INCLUDED") && B_PROLOG_INCLUDED===true)
{
	require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog.php");
}
?>