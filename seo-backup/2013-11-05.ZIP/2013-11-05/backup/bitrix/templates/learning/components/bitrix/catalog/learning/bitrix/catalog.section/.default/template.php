<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<? if (empty($arResult["DESCRIPTION"])): ?>

    <div class="prodbox">
        
        <?foreach($arResult["ITEMS"] as $cell=>$arElement):?>
        
            <div class="news-content" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
               
               <div class="news-title"> <a href="<?=$arElement["DETAIL_PAGE_URL"]?>" class="plink"><?=$arElement["NAME"]?></a><br/></div>
                <div class="news-prevtext"><?=$arElement["PREVIEW_TEXT"]?></div>
            </div>

            
        <?endforeach;?>
    </div>
  
<?
else:?>
<div class="news-content">
<div class="news-prevtext"><?=$arResult["DESCRIPTION"]?></div></div>

<?endif;?> 